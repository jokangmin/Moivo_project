import type { Modifier } from "../types";
export declare type ApplyStylesModifier = Modifier<"applyStyles", {}>;
declare const _default: ApplyStylesModifier;
export default _default;
