export default function getComputedStyle(element: Element): CSSStyleDeclaration;
