declare function arrayBufferByteLength(buffer: ArrayBuffer): number;
declare function arrayBufferByteLength(buffer: unknown): typeof NaN;

export = arrayBufferByteLength;