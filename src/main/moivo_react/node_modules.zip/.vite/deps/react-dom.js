import {
  require_react_dom
} from "./chunk-GKJBSOWT.js";
import "./chunk-QJTFJ6OV.js";
import "./chunk-V4OQ3NZ2.js";
export default require_react_dom();
//# sourceMappingURL=react-dom.js.map
