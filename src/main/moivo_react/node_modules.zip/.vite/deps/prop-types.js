import {
  require_prop_types
} from "./chunk-XOPD35QN.js";
import "./chunk-V4OQ3NZ2.js";
export default require_prop_types();
//# sourceMappingURL=prop-types.js.map
