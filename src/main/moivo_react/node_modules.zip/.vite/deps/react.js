import {
  require_react
} from "./chunk-QJTFJ6OV.js";
import "./chunk-V4OQ3NZ2.js";
export default require_react();
//# sourceMappingURL=react.js.map
